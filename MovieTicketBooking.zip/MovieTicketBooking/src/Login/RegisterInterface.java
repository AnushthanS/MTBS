package Login;

public interface RegisterInterface {
    void inputPrompt();
    void dataEntry();
}
