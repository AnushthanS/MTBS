package Login;
interface LoginInterface{
    void inputPrompt();
    void authentication();
}
