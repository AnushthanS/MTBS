package Test;

import Core.DataImport;

public class TestDataImport {
    public static void main(String[] args) {
        DataImport dataImport = new DataImport();
        dataImport.refresh();
    }
}
