package Test;

import TicketBooking.*;

public class TestTicketBooking {
    public static void main(String[] args) {
        TicketBooking ticketBooking = new TicketBooking("ijkl@xyz.com");
        ticketBooking.startBooking();
    }
}
